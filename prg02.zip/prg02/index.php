<?php

?>

<!DOCTYPE html>
<html>
<head>
    <title>Maak een Afspraak</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<h1>Maak een Afspraak</h1>

<form>
    <label for="datum">Datum:</label>
    <br>
    <input type="date" id="datum" name="datum">
    <br>
    <label for="vn">Voornaam:</label>
    <br>
    <input type="text" id="vn" name="vn">
    <br>
    <label for="an">Achternaam:</label>
    <br>
    <input type="text" id="an" name="an">
    <br>
    <label for="wpl">Woonplaats:</label>
    <br>
    <input type="text" id="wpl" name="wpl">
    <br>
    <label for="adres">Adres:</label>
    <br>
    <input type="text" id="adres" name="adres">
    <br>
    <label for="email">Email-Adres:</label>
    <br>
    <input type="email" id="email" name="email">
    <br>
    <label for="tele">Telefoonnummer:</label>
    <br>
    <input type="tel" id="tele" name="tele" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}">
    <br>
    <label for="opm">Opmerkingen:</label>
    <br>
    <input type="text" id="opm" name="opm">
    <br>
    <input id="Submit" type="button" name="Submit" value="Submit">
</form>

</body>
</html>
