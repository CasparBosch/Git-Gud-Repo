<?php
$user = `root`;
$pass = ``;
$db = `db_reserveringssysteem`;

// Create connection
$conn = mysqli_connect(`localhost`, $user, $pass, $db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
    $stmt = $conn->prepare("insert into registration(datum, voornaam, achternaam, woonplaats, adres, email, telefoonnummer, opmerkingen)
        values(?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssis", $datum, $voornaam, $achternaam, $woonplaats, $adres, $email, $telefoonnummer, $opmerkingen);
    $stmt->execute();
    $stmt->close();
}
echo "Connected successfully";

mysqli_close($conn);
?>

<html lang="html">
<body>
<?php echo $_post["Voornaam"]; ?>!<br>
<?php echo $_post["Achternaam"]; ?>!<br>
<?php echo $_post["Telefoonnummer"]; ?>!<br>
<?php echo $_post["Email"]; ?>!<br>
<?php echo $_post["Woonplaats"]; ?>!<br>
<?php echo $_post["Adres"]; ?>!<br>
<?php echo $_post["Postcode"]; ?>!<br>
<?php echo $_post["Type Afspraak"]; ?>!<br>
<?php echo $_post["Weeknummer"]; ?>!<br>
<?php echo $_post["Datum"]; ?>!<br>
<?php echo $_post["Tijd"]; ?>!<br>
<?php echo $_post["Opmerkingen"]; ?>!<br>
</body>
</html>