<?php
$voornaam = "Voornaam". "<br>";
$achternaam = "Achternaam". "<br>";
$telefoonnummer = "Telefoonnummer". "<br>";
$email = "Email". "<br>";
$woonplaats = "Woonplaats". "<br>";
$adres = "Adres". "<br>";
$postcode = "Postcode". "<br>";
$afspraak = "Type Afspraak". "<br>";
$weeknummer = "Weeknummer". "<br>";
$datum = "Datum". "<br>";
$tijd = "Tijd". "<br>";
$opmerkingen = "Opmerkingen". "<br>";
?>