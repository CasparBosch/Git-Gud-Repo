<?php
require_once "DB_Connect.php";
$conn = openConn();

function createData(){
    //making variables of the checked input
    $voornaam = textboxValue("Voornaam");
    $achternaam = textboxValue("Achternaam");
    $email = textboxValue("Email");
    $telefoonnummer = textboxValue("Telefoonnummer");
    $adres = textboxValue("Adres");
    $datum = textboxValue("Datum");
    $tijd = textboxValue("Tijd");
    $opmerkingen = textboxValue("Opmerkingen");
    $woonplaats = textboxValue("Woonplaats");

    // variables in to the db
    if ($datum&&$tijd&&$voornaam&&$achternaam&&$woonplaats&&$adres&&$email&&$telefoonnummer&&$opmerkingen){
        $sql = "INSERT INTO contact(Datum, Tijd, Voornaam, Achternaam, Woonplaats, Adres, Email, Telefoonnummer, Opmerkingen) 
        VALUES('$datum', '$tijd', '$voornaam', '$achternaam', '$woonplaats', '$adres', '$email', '$telefoonnummer', '$opmerkingen')";
        if(mysqli_query($GLOBALS['conn'], $sql)){
            TextNode("succes", "Afpraak is succesvol toegevoegd!");
        }else{
            echo "Error";
        }
    }else{
        TextNode("error", "Voer alle gegevens in");   }
}


//checking textbox value and mysql injections
function textboxValue($value){
    $textbox = mysqli_real_escape_string($GLOBALS['conn'], trim($_POST[$value] ));
    if(empty($textbox)){
        return false;
    }else{
        return $textbox;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="styleJesper.css">
</head>
</html>